const getters = {
    userInfo: state => {
        return state.user
    }
}

export default getters