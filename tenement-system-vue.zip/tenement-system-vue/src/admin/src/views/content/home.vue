<template>
    <div class="home">
        <img src="@/assets/images/tit.png" />
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>
.home {
    padding: 100px;
    width: 100%;
    height: 100%;
    background-image: url(../../assets/images/head-img.png);
    background-repeat: no-repeat;
}
</style>
